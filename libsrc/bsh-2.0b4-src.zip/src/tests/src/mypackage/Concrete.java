package mypackage;

public class Concrete extends AbstractBase { }
