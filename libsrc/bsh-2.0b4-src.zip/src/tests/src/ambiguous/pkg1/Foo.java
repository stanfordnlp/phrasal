package ambiguous.pkg1;

public class Foo {
	public static String pkg ="pkg1";
}
