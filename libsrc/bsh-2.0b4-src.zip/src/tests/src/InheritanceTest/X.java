package InheritanceTest;

public class X extends W {
	public void a() {
		System.out.println("X.a()");
	}
	public void x() {
		System.out.println("X.x()");
	}
	void x_() {
		System.out.println("X.x_()");
	}
}
