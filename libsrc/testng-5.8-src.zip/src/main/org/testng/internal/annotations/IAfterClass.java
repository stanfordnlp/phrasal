package org.testng.internal.annotations;

public interface IAfterClass extends IBaseBeforeAfter {

}
