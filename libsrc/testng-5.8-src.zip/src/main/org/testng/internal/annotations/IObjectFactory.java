package org.testng.internal.annotations;

/**
 * @author Hani Suleiman
 *         Date: Mar 6, 2007
 *         Time: 2:16:13 PM
 */
public interface IObjectFactory extends IAnnotation
{
}
